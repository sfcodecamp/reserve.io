'use strict';
var axios = require('axios');

// var AWS_KEY = 'AKIAI7OOBHYAHYENENXA';
// var AWS_SECRET = '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';

module.exports.opentable = (event, context, callback) => {
  //
  // let city = 'San Francisco';
  // // check for GET params and use if available
  // if (event.queryStringParameters && event.queryStringParameters.city) {
  //   city = event.queryStringParameters.city;
  // }

  const baseURL = `https://platform.otqa.com/sync/`
  const auth = 'Bearer 27037c67-f394-4cfd-ab51-069ac71132fb'

  ///////// multi-rid search availability by location ///////////
  // let params = {
  //   // latitude: 37.7938190,
  //   // longitude: -122.3950890,
  //   latitude: 36.1627,
  //   longitude: 86.7816,
  //   party_size: 2,
  //   radius: 10,
  //   forward_minutes: 180,
  //   backward_minutes: 30,
  //   start_date_time: '2017-03-17T17:00',
  //   include_unavailable: true
  // }

  // price - Price range for the restaurant. Values: 1-4.
  // name - Name of the restaurant
  // address - Address line. Should not contain state or city or zip.
  // state - State code (ex.: IL)
  // city - City name (ex.: Chicago)
  // zip - Zipcode (ex: 60601)
  // country - Country code (ex: US)
  // page - Page (default: 1)
  // per_page - Entries per Page, can be one of [5, 10, 15, 25, 50, 100] (default: 25)

  let city = (event.queryStringParameters && event.queryStringParameters.city) ? event.queryStringParameters.city : 'San Francisco';

  const publicAPI = `http://opentable.herokuapp.com/api/restaurants?city=${city}`;

  const getAvailabilityByLoc = () => {
    // const url = 'listings'
    // axios.get(url, {
    //   baseURL: baseURL,
    //   headers: {'Authorization': auth},
    //   params: params
    // })
    axios.get(`${publicAPI}`).then(result => {

      var response = {
        statusCode: 200,
        body: JSON.stringify({
          message: result.data
        })
      };

      callback(null, response);

    }).catch(error => {

      var response = {
        statusCode: 200,
        body: JSON.stringify({
          message: 'ERROR'
        })
      };

      callback(null, response);

    });
  }

  getAvailabilityByLoc();

};

module.exports.landingPage = (event, context, callback) => {
  let dynamicHtml = '<p>Hey Unknown!</p>';
  // check for GET params and use if available
  if (event.queryStringParameters && event.queryStringParameters.name) {
    dynamicHtml = `<p>Hey ${event.queryStringParameters.name}!</p>`;
  }

  const html = `
    <html>
      <body>
        <h1>Landing Page</h1>
        ${dynamicHtml}
      </body>
    </html>`;

  const response = {
    statusCode: 200,
    headers: {
      'Content-Type': 'text/html',
    },
    body: html,
  };

  // callback is sending HTML back
  callback(null, response);
};
